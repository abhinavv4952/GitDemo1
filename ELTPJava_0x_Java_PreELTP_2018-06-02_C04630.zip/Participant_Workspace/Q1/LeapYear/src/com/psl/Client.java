package com.psl;

public class Client {

	public boolean isLeapYear(int year) {
		
		// Write your code here to test if the year passed as a parameter is a Leap Year or not.
	}

	public static void main(String[] args) {
		
	}

}
