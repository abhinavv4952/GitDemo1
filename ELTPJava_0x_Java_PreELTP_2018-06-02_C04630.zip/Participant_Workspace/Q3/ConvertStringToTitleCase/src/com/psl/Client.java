package com.psl;

public class Client {

	public String convertToTitle(String string){
	
		//Write the code here to Convert the String to title case
        return null;

        
	}
		public static void main(String[] args) {
			// Test your code by calling convertToTitle method from here			
		}
}
